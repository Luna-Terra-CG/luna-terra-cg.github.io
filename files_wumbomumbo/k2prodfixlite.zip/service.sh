#!/system/bin/sh
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
done

sleep 10

# 100 seems to just hammer the cpu when struggling for ram
sysctl -w vm.swappiness=60
