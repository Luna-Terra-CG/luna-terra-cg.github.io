#!/system/bin/sh
echo 3 > /proc/sys/vm/drop_caches
swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo 2147483648 > /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon /dev/block/zram0
